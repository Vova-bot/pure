<?php

define('LANDING_DIR', '');

$apiKey = 'CjhJqrUxZTTGQXslLaqaZYDjLrfkhTn0X5ShpP';          // Ключ доступа к API
$offer_id = 4371;         // для каждого оффера свой айди, надо уточнять его в админке или у суппортов
$stream_hid = 'wV6UGvxN';     // id потока
$landKey = '8ca545e780fce1d21e692da7acaceba8';

$default_main_site = 'http://api.cpa.tl';
$apiSendLeadUrl = 'http://api.cpa.tl/api/lead/send_archive';
$apiGetLeadUrl = 'http://api.cpa.tl/api/lead/feed';

$dataOffers = '{"18062":{"id":18062,"name":"Pure Foundation","country":{"code":"RO","name":"\u0420\u0443\u043c\u044b\u043d\u0438\u044f"},"price":"165","price2":"330","currency":{"code":"RON","name":"RON"}}}';
$dataOffer = '{"id":18062,"name":"Pure Foundation","country":{"code":"RO","name":"\u0420\u0443\u043c\u044b\u043d\u0438\u044f"},"price":"165","price2":"330","currency":{"code":"RON","name":"RON"}}';
$is_geo_detect = '';
$productName = 'Pure Foundation';
$invoice = 'index.php';
$push_link = '';
$language = 'ro';
$companyInfo = array('address' => '443090, Самарская область, г. Самара, ул. Советской армии, д. 140Б, офис 64', 'detail' => 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ "РЕГИОН-ТОРГ" ОГРН: 1196313080457 ИНН: 6316260119 КПП: 631801001');
$companyInfoEN = array('address' => '129090, Moscow, pereulok Zhivarev, house 8, stroenie 3, flat 16 email: ostrov.prodazh@mail.com Skype: ostrov.prodazh@mail.com', 'detail' => 'OOO "OSTROV PRODAZH" OGRN: 1197746695530 VAT: 7708365555');
$fb_verification = '';

$_debug = False; // установите True для вывода дополнительной информации для отладки и поиска ошибок
$pixels = [
    'fb_pixel', 'fb_verify', 'google_pixel', 'google_adw_pixel', 'tiktok_pixel', 'topmail_pixel', 'vk_pixel', 'yandex_metrika',
];

if(!$apiKey){
    echo 'Ключ доступа к API не определен. Получите в личном кабинете или обратитесь в службу поддержки';
    die;
}

if(!$offer_id){
    echo 'ID оффера не определен';
    die;
}
