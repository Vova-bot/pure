<?php require('onepage.php') ?>
<!DOCTYPE html>
<html >

<head>
    <link rel="shortcut icon" href="1.jpg" type="image/png">
    <title>Pure Foundation e un fond de ten exceptional, hipoalergic, rezistent la apa!</title>
    <!-- Favicon -->

    <meta name="description"
        content="Pure Foundation e un fondotinta eccezionale, antiallergico, resistente all’acqua.">

   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width">

    <!-- CSS -->
    <link type="text/css" rel="stylesheet" href="css/slick.css" />
    <link type="text/css" rel="stylesheet" href="css/style-54421.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery.simplecolorpicker.css">

    <!-- JS -->
    <script src="js/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/timer.js"></script>
    <script type="text/javascript" src="js/slick.min.js"></script>
    <script type="text/javascript" src="js/script-543321.js"></script>
    <script src="js/jquery.simplecolorpicker.js"></script>

</head>

<body class="lang-ro">

    <div class=" ">
        <div class="b1">

            <div class="section">
                <div class="zag">
                    <h1>Fond de ten de calitate</h1>
                    <h2 class="bold"> <span class="pink">Pure Foundation</span></h2>
                </div>
                <div class="sale white center">
                    <p class="upp">reducere</p>
                    <h3 class="bold">50%</h3>
                </div>
                <p class="price center">
                    <span class="old"><span class="price_land_s2"><?= $oldPriceHtml ?></span> <span
                            class="price_land_curr"><?= $currencyDisplayHtml ?></span></span>
                    <span class="new bold orange"><span class="price_land_s1"><?= $newPriceHtml ?></span> <span
                            class="price_land_curr"><?= $currencyDisplayHtml ?></span></span>
                </p>

                <a class="white button upp medium" href="#go">Comandă</a>
            </div>
        </div>
        <div class="b2">
            <div class="section">
                <h2 class="h2 ser">Despre <span class="pink bold">Pure Foundation</span></h2><img alt="Pure Foundation"
                    src="img/product.png" title="Pure Foundation">
                <h3 class="dark1 bold">Pure Foundation </h3>
                <p>Pure Foundation este un fond de ten excepțional, <span style="font-weight: bold;">hipoalergenic,
                        rezistent la apă, cu efect matifiant.</span> Compoziția inovatoare, cu un conținut de pigment de
                    50% ascunde imperfecțiunile pielii, netezește tenul și îi conferă un aspect perfect, chiar dacă este
                    aplicat într-o cantitate mică. Ascunde cu ușurință acneea, petele pigmentare și tatuajele. <span
                        style="font-weight: bold;">De asemenea poate fi aplicat atât pe întreaga față cât și pe corp
                        pentru a uniformiza culoarea tenului sau pentru a face pielea mai luminoasă sau bronzată.</span>
                    Crema este adesea folosită de fotografii profesionisti, de actori sau pentru evenimente speciale.
                </p>
            </div>
        </div>
        <!--<div class="b3">-->
        <!--<div class="section">-->
        <!--<h2 class="h2 ser">6 ОТТЕНКОВ <span class="pink bold">ПОД КАЖДЫЕ ГУБКИ</span></h2><img alt="Pure Foundation" class="web" src="files/kylie_edition_1/img/b3_1-min.png" title="Pure Foundation"> <img alt="Pure Foundation" class="mob" src="files/kylie_edition_1/img/b3_mob.jpg" title="Pure Foundation"></div>-->
        <!--</div>-->
        <div class="b13  shades_section">
            <div class="b4">
                <div class="section">
                    <h2 class="h2 ser">Beneficiile <span class="pink bold">PURE FOUNDATION</span></h2>
                    <ul>
                        <li>
                            <img alt="Pure Foundation" src="img/b4_3.png" title="Pure Foundation">
                            <h3 class="medium">Pentru toate tipurile de piele</h3>
                        </li>
                        <li>
                            <img alt="Pure Foundation" src="img/b4_3.png" title="Pure Foundation">
                            <h3 class="medium">Hipoalergenic</h3>
                        </li>
                        <li>
                            <img alt="Pure Foundation" src="img/b4_3.png" title="Pure Foundation">
                            <h3 class="medium">Rezistent la apă</h3>
                        </li>
                        <li>
                            <img alt="Pure Foundation" src="img/b4_3.png" title="Pure Foundation">
                            <h3 class="medium">SPF 15</h3>
                        </li>

                    </ul><a class="white button upp medium" href="#go">Comandă</a>
                </div>
            </div>
            <div class="section">
                <h2 class="h2 ser">Nuanțe disponibile <span class="pink bold">Pure Foundation</span></h2>

                <div class="wrapper clearfix">


                    <div class="shades_list column_left">

                        <div class="shade_item clearfix">
                            <div class="shade_block">
                                <div class="shade number207 img-click" id="1"></div>
                            </div>
                            <div class="info">
                                <div class="number">100</div>
                                <p>Nude (subton cald)</p>
                            </div>
                        </div>

                        <div class="shade_item clearfix">
                            <div class="shade_block">
                                <div class="shade number209 img-click" id="2"></div>
                            </div>
                            <div class="info">
                                <div class="number">120</div>
                                <p>Avorio (subton neutru)</p>
                            </div>
                        </div>


                        <div class="shade_item clearfix">
                            <div class="shade_block">
                                <div class="shade number212 img-click" id="3"></div>
                            </div>
                            <div class="info">
                                <div class="number">130</div>
                                <p>Naturale (subton cald)</p>
                            </div>
                        </div>

                        <a class="white button upp medium" href="#go">Comandă</a>
                    </div>

                </div>
            </div>
        </div>

        <!--<div class="b5">-->
        <!--<div class="section">-->
        <!--<h2 class="h2 white">МАТОВЫЕ ПОМАДЫ KYLIE <span class="pink bold">ВЫБИРАЮТ ЗВЕЗДЫ</span></h2><img alt="Pure Foundation" src="files/kylie_edition_1/img/b5_1-min.png" title="Pure Foundation"></div>-->
        <!--</div>-->
        <div class="b6">
            <div class="section">
                <h2 class="h2 ser">Recensioni di <span class="pink bold">Pure Foundation</span></h2>
                <div class="slider-wrap">
                    <div class="rev item">
                        <div class="rev_inner rev_inner1">
                            <h3 class="medium">Nicole, 35 ani</h3>
                            <p>Sunt mega mulțumită de acest fond de ten! Este CEL MAI BUN! De acum înainte mă voi folosi
                                doar de el. RECOMAND tuturor fetelor care au un ten imperfect, dar visează la o piele
                                curată și netedă. Acest produs este cel mai bun dintre toate cele încercate de mine.<img
                                    alt="Pure Foundation" class="smile" src="img/s1.png" title="Pure Foundation"></p>
                            <img alt="Pure Foundation" class="o_avtor o_avtor1" src="img/reviews__review2_photo.jpg"
                                title="Pure Foundation">
                        </div>
                    </div>
                    <div class="rev item">
                        <div class="rev_inner">
                            <h3 class="medium">Ana, 32 ani</h3>
                            <p>După 2 luni de utilizare, pot spune că această cremă ascunde perfect toate neajunsurile,
                                indiferent dacă este acnee, pete sau roșeață. Îmi place că sunt disponibile multe nuanțe
                                la alegere. Produsul este foarte econom, ajunge pentru o perioadă lungă de timp. Poate
                                fi folosit ca un corector pentru mascarea defectelor individuale. Recomand tuturor!<img
                                    alt="Pure Foundation" class="smile" src="img/s3.png" title="Pure Foundation"><img
                                    alt="Pure Foundation" class="smile" src="img/s2.png" title="Pure Foundation"><img
                                    alt="Pure Foundation" class="smile" src="img/s4.png" title="Pure Foundation"></p>
                            <img alt="Pure Foundation" class="o_avtor o_avtor2" src="img/reviews__review1_photo.jpg"
                                title="Pure Foundation">
                        </div>

                    </div><!-- michael-k90 -->
                    <div class="rev item">
                        <div class="rev_inner">
                            <h3 class="medium">Catalina, 27 ani</h3>
                            <p>De un an folosesc acest fond de ten. <img alt="Pure Foundation" class="smile"
                                    src="img/s2.png" title="Pure Foundation"><br>
                                Este minunat, pentru că: are un efect ultra-matifiant, are o textura densă, este
                                hipoalergenic și rezistent la apă, are un preț accesibi și cel mai important - după
                                aplicare pielea devine moale, netedă și catifelată. Recomand celor ce au probleme cu
                                tenul, cred că o opțiune mai bună nu există. <img alt="Pure Foundation" class="smile"
                                    src="img/s3.png" title="Pure Foundation"><img alt="Pure Foundation" class="smile"
                                    src="img/s3.png" title="Pure Foundation"><img alt="Pure Foundation" class="smile"
                                    src="img/s3.png" title="Pure Foundation"></p>
                            <img alt="Pure Foundation" class="o_avtor o_avtor3" src="img/reviews__review3_photo.jpg"
                                title="Pure Foundation">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="b7">
            <div class="section white">
                <ul>
                    <li>
                        <img alt="Pure Foundation" src="img/b7_1.jpg" title="Pure Foundation">
                        <p class="white-3">Livrarea exclusiv prin curier în 3-5 zile</p>
                    </li>
                    <li>
                        <img alt="Pure Foundation" src="img/b7_2.jpg" title="Pure Foundation"><!-- bizlife_inc -->
                        <p class="white-3">Achitați în numerar la primirea coletului</p>
                    </li>
                    <li>
                        <img alt="Pure Foundation" src="img/b7_3.jpg" title="Pure Foundation">
                        <p class="white-3">Aveți dreptul să anulați achiziția în termen de 14 zile</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="b8" id="go">
            <div class="section">
                <div class="left">
                    <div class="zag">

                        <h1>Fond de ten de calitate</h1>
                        <h2 class="bold"> <span class="pink">Pure Foundation</span></h2>

                    </div>
                    <div class="sale white center">
                        <p class="upp">reducere</p>
                        <h3 class="bold">50%</h3>
                    </div>
                </div>
                <div class="right">
                    <p class="white deadline center medium">Promoția durează:</p>
                    <div class="el-timer" id="timer">
                        <div class="timebox">
                            <p class="hours">00</p><span>ORE</span>
                        </div>
                        <div class="timebox">
                            <p class="minutes">00</p><span>MINUTE</span>
                        </div>
                        <div class="timebox">
                            <p class="seconds">00</p><span>SECONDE</span>
                        </div>
                    </div>
                    <p class="price center">
                        <span class="old white"><span class="price_land_s2"><?= $oldPriceHtml ?></span> <span
                                class="price_land_curr"><?= $currencyDisplayHtml ?></span></span>
                        <span class="new bold orange"><span class="price_land_s1"><?= $newPriceHtml ?></span> <span
                                class="price_land_curr"><?= $currencyDisplayHtml ?></span></span>
                    </p>
                    <form id="form" class="order_form" action="" method="POST">
                        <?= countryDefault() ?> 
                        <input class="input" type="text" name="name"  placeholder="Introduceți numele"
                            required="">
                        <input class="input" type="tel" name="phone" placeholder="Nr. de telefon"
                            required="">


                        <div class="input color-pick">Alegeți culoarea
                            <select name="colorpicker-picker-delay" id="color" class="unic">
                                <option value="#F3CFB3">100</option>
                                <option value="#EDC8A3">120</option>
                                <option value="#E7B78A">130</option>
                            </select>
                        </div>
                        <input type="hidden" name="comments" val="" class="unic_comment">
                        <button type="submit" class="button">Comandă</button>

                    </form>


                </div>
            </div>
        </div>

        <div class="b10">
            <div class="section"></div>
        </div>
    </div>

  


    <script>

                //   console.log(  $('.unic_comment').val($('.unic option:selected').text()));
        // console.log( $('.unic option:selected').text());
        $('.color-pick').change(function () {
            // console.log('Changed :)');
            $('.unic_comment').val("color: " + $('.unic option:selected').text())

        });
        $('select[name="colorpicker-picker-delay"]').simplecolorpicker({
            picker: true,
            theme: 'glyphicons',
            pickerDelay: 500
        });

        $("span.color").each(function (i) {
            $(this).attr('id', 'test' + i);
        });


        $('#test0').on('click', function () {
            $('.simplecolorpicker').addClass('first');
            $('.simplecolorpicker').removeClass('second');
            $('.simplecolorpicker').removeClass('third');
            $('.simplecolorpicker').removeClass('fourth');
        });
        $('#test1').on('click', function () {
            $('.simplecolorpicker').addClass('second');
            $('.simplecolorpicker').removeClass('first');
            $('.simplecolorpicker').removeClass('third');
            $('.simplecolorpicker').removeClass('fourth');
        });
        $('#test2').on('click', function () {
            $('.simplecolorpicker').removeClass('second');
            $('.simplecolorpicker').removeClass('first');
            $('.simplecolorpicker').addClass('third');
            $('.simplecolorpicker').removeClass('fourth');
        });
        $('#test3').on('click', function () {
            $('.simplecolorpicker').removeClass('second');
            $('.simplecolorpicker').removeClass('first');
            $('.simplecolorpicker').removeClass('third');
            $('.simplecolorpicker').addClass('fourth');
        });
       
    </script>
	<center><?= footer('en') ?></center>
</body>

</html>