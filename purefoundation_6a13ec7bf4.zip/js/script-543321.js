$(document).ready(function() {

    $('[name="country"]').on('change', function() {
        var geoKey = $(this).find('option:selected').val();
        var data = $jsonData.prices[geoKey];
        var price = data.price;
        var oldPrice = data.old_price;
        var currency = data.currency
        $("[value = "+geoKey+"]").attr("selected", true).siblings().attr('selected', false);

        $('.price_land_s1').text(price);
        $('.price_land_s2').text(oldPrice);
        $('.price_land_curr').text(currency);
    });


    $('a[href*="#"]:not([href="#"])').click(function() {
        if (location.pathname.replace(/^\//, "") == this.pathname.replace(/^\//, "") && location.hostname == this.hostname) {
            var t = $(this.hash);
            if (t = t.length ? t : $("[name=" + this.hash.slice(1) + "]"), t.length) return $("html, body").animate({
                scrollTop: t.offset().top
            }, 1e3), !1
        }
    });

    $('.slider-wrap').slick({
        autoplay: true,
        autoplaySpeed: 4000,
    });

    var actionBanner = $('#actionBanner');
     $('#closeKBBar').on('click', function(e) {
        actionBanner.fadeOut(200, function() {
            actionBanner.remove();
        });
        e.preventDefault();
    });
    var dateNow = new Date();
    actionBanner.find('.curMonth').text(months[dateNow.getMonth()]);

    initializeClock('timer', deadline);

});

var months = ['январь','фeвраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь'];